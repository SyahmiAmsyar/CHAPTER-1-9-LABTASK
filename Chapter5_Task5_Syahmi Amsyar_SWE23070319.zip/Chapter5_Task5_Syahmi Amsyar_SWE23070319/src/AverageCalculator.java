public class AverageCalculator {
    public static void displayAverages(Learner learner1, Learner learner2, Learner learner3) {
        // Calculate and display the averages
        double average1 = learner1.computeAverage();
        double average2 = learner2.computeAverage();
        double average3 = learner3.computeAverage();

        System.out.println(learner1.getStudentName() + "'s Average Score: " + average1);
        System.out.println(learner2.getStudentName() + "'s Average Score: " + average2);
        System.out.println(learner3.getStudentName() + "'s Average Score: " + average3);
    }
}
