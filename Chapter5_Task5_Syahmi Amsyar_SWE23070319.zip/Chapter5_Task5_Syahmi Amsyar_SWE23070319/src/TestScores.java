public class TestScores {
    public static void main(String[] args) {
        // Create 3 Learner objects with different scores
        Learner learner1 = new Learner("Faiq", 78, 85, 92);
        Learner learner2 = new Learner("Irfan", 88, 76, 91);
        Learner learner3 = new Learner("Nafie", 83, 79, 87);

        // Display the averages for all learners
        AverageCalculator.displayAverages(learner1, learner2, learner3);

        // Calculate the highest average using Math.max method
        double highestAverage = Math.max(learner1.computeAverage(), 
                               Math.max(learner2.computeAverage(), learner3.computeAverage()));

        // Display the highest average
        System.out.println("The highest average score is: " + highestAverage);
    }
}
