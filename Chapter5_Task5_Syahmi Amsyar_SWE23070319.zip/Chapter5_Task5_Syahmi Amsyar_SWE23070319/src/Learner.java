public class Learner {
    private String studentName;
    private int score1, score2, score3;

    // Constructor
    public Learner(String studentName, int score1, int score2, int score3) {
        this.studentName = studentName;
        this.score1 = score1;
        this.score2 = score2;
        this.score3 = score3;
    }

    // Method to compute the average score
    public double computeAverage() {
        return (score1 + score2 + score3) / 3.0;
    }

    // Getter for student name
    public String getStudentName() {
        return studentName;
    }
}
