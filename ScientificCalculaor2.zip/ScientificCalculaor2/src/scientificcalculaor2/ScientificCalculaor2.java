package scientificcalculaor2;

import javax.swing.*;

public class ScientificCalculaor2 {
    private static double memory = 0;  // Memory storage for saving values
    private static StringBuilder history = new StringBuilder();  // History storage to keep track of previous calculations

    public static void main(String[] args) {


        boolean running = true;  // Variable to control the main loop for operation selection

        while (running) {
            // Show a dialog to choose between basic and scientific modes
            String[] modes = {"Basic Calculation", "Scientific Calculation"};
            String mode = (String) JOptionPane.showInputDialog(
                    null,  // Parent component
                    "Choose mode:",  // Message to display
                    "Mode Selection",  // Dialog title
                    JOptionPane.QUESTION_MESSAGE,  // Type of message (question)
                    null,  // Icon (null for default)
                    modes,  // Array of available options
                    modes[0]  // Default selection
            );

            if (mode == null) break;  // Exit if the user presses "Cancel" or closes the dialog

            // Perform operations based on the selected mode
            switch (mode) {
                case "Basic Calculation":
                    performBasicCalculations();  // Calls function for basic calculations
                    break;
                case "Scientific Calculation":
                    performScientificCalculations();  // Calls function for scientific calculations
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid mode selected.");  // Shows an error if the mode is invalid
            }
        }
    }

    // Function to handle basic calculations (add, subtract, multiply, divide)
    private static void performBasicCalculations() {
        boolean basicRunning = true;  // Variable to control the basic calculation loop

        while (basicRunning) {
            // Show a dialog to select a basic operation
            String[] basicOperations = {"Add", "Subtract", "Multiply", "Divide", "View History", "Clear History"};
            String operation = (String) JOptionPane.showInputDialog(
                    null,  // Parent component
                    "Choose a basic operation:",  // Message to display
                    "Basic Calculation",  // Dialog title
                    JOptionPane.QUESTION_MESSAGE,  // Type of message
                    null,  // Icon (null for default)
                    basicOperations,  // Array of operations
                    basicOperations[0]  // Default selection
            );

            if (operation == null) break;  // Exit if the user presses "Cancel" or closes the dialog

            // Perform selected operation
            switch (operation) {
                case "Add":
                    performBasicOperation("+");  // Perform addition
                    break;
                case "Subtract":
                    performBasicOperation("-");  // Perform subtraction
                    break;
                case "Multiply":
                    performBasicOperation("*");  // Perform multiplication
                    break;
                case "Divide":
                    performBasicOperation("/");  // Perform division
                    break;
                case "View History":
                    viewHistory();  // Display history of calculations
                    break;
                case "Clear History":
                    clearHistory();  // Clear history of calculations
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid operation.");  // Show an error for invalid operations
            }
        }
    }

    // Function to handle scientific calculations (trigonometry, log, power, etc.)
    private static void performScientificCalculations() {
        boolean scientificRunning = true;  // Variable to control the scientific calculation loop

        while (scientificRunning) {
            // Show a dialog to select a scientific operation
            String[] scientificOperations = {
                    "Sin", "Cos", "Tan", "Log", "Ln", "Power (x^y)", "Exponent (e^x)",
                    "1/x", "Negate (±)", "Memory Save", "Memory Recall", "Memory Clear",
                    "View History", "Clear History"
            };
            String operation = (String) JOptionPane.showInputDialog(
                    null,  // Parent component
                    "Choose a scientific operation:",  // Message to display
                    "Scientific Calculation",  // Dialog title
                    JOptionPane.QUESTION_MESSAGE,  // Type of message
                    null,  // Icon (null for default)
                    scientificOperations,  // Array of operations
                    scientificOperations[0]  // Default selection
            );

            if (operation == null) break;  // Exit if the user presses "Cancel" or closes the dialog

            try {
                // Perform the selected scientific operation
                switch (operation) {
                    case "Sin":
                        performTrigOperation("sin");  // Perform sine operation
                        break;
                    case "Cos":
                        performTrigOperation("cos");  // Perform cosine operation
                        break;
                    case "Tan":
                        performTrigOperation("tan");  // Perform tangent operation
                        break;
                    case "Log":
                        performLogOperation("log");  // Perform log base 10 operation
                        break;
                    case "Ln":
                        performLogOperation("ln");  // Perform natural log (ln) operation
                        break;
                    case "Power (x^y)":
                        performPowerOperation();  // Perform power operation
                        break;
                    case "Exponent (e^x)":
                        performExponentOperation();  // Perform exponentiation operation
                        break;
                    case "1/x":
                        performInverseOperation();  // Perform inverse operation
                        break;
                    case "Negate (±)":
                        performNegationOperation();  // Negate the number
                        break;
                    case "Memory Save":
                        memorySave();  // Save value to memory
                        break;
                    case "Memory Recall":
                        memoryRecall();  // Recall value from memory
                        break;
                    case "Memory Clear":
                        memoryClear();  // Clear memory
                        break;
                    case "View History":
                        viewHistory();  // Show history of operations
                        break;
                    case "Clear History":
                        clearHistory();  // Clear calculation history
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Invalid operation.");  // Error for invalid operation
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());  // Display any error that occurs during the operation
            }
        }
    }

    // Function to perform basic operations: add, subtract, multiply, divide
    private static void performBasicOperation(String operator) {
        double num1 = getNumberInput("Enter the first number:");  // Get first number from the user
        if (num1 == Double.NaN){return;}  // Exit if the user cancels or enters invalid input
        double num2 = getNumberInput("Enter the second number:");  // Get second number from the user
        if (num2 == Double.NaN) {return; } // Exit if the user cancels or enters invalid input
        
        double result = 0;  // Variable to store the result of the operation

        // Perform the operation based on the selected operator
        switch (operator) {
            case "+":
                result = num1 + num2;
        // Append the calculation and result to the history
        String calculation = num1 + " " + operator + " " + num2 + " = " + result;
        history.append(calculation).append("\n");
        JOptionPane.showMessageDialog(null, "Result: " + result);  // Display the result
                break;
            case "-":
                result = num1 - num2;
        // Append the calculation and result to the history
        calculation = num1 + " " + operator + " " + num2 + " = " + result;
        history.append(calculation).append("\n");
        JOptionPane.showMessageDialog(null, "Result: " + result);  // Display the result
                break;
            case "*":
                result = num1 * num2;
        // Append the calculation and result to the history
        calculation = num1 + " " + operator + " " + num2 + " = " + result;
        history.append(calculation).append("\n");
        JOptionPane.showMessageDialog(null, "Result: " + result);  // Display the result
                break;
            case "/":
                try {
                // Code that might throw an ArithmeticException, like division by zero
                if (num2 == 0) {
                throw new ArithmeticException("Cannot divide by zero");
                } else {
                result = num1 / num2;
        // Append the calculation and result to the history
        calculation = num1 + " " + operator + " " + num2 + " = " + result;
        history.append(calculation).append("\n");
        JOptionPane.showMessageDialog(null, "Result: " + result);  // Display the result
                }
                } catch (ArithmeticException e) {
        // Display the exception message in a dialog box
        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
                break;
        }


    }

    // Function to perform trigonometric operations: sin, cos, tan
    private static void performTrigOperation(String trigFunction) {
        double num = getNumberInput("Enter the angle (in radians):");  // Get angle from the user
        if (num == Double.NaN) return;  // Exit if the user cancels or enters invalid input
        
        double result = 0;  // Variable to store the result
        
        // Perform the selected trigonometric function
        switch (trigFunction) {
            case "sin":
                result = Math.sin(num);
                break;
            case "cos":
                result = Math.cos(num);
                break;
            case "tan":
                result = Math.tan(num);
                break;
            default:
                JOptionPane.showMessageDialog(null, "Invalid trigonometric function.");
                return;
        }

        // Append the calculation and result to the history
        String calculation = trigFunction + "(" + num + ") = " + result;
        history.append(calculation).append("\n");
        JOptionPane.showMessageDialog(null, "Result: " + result);  // Display the result
    }

    // Function to perform logarithmic operations: log base 10 or ln
    private static void performLogOperation(String logType) {
        double num = getNumberInput("Enter the number:");  // Get the number for log operation
        if (num == Double.NaN) return;  // Exit if the user cancels or enters invalid input
        
        double result = 0;  // Variable to store the result
        
        // Perform the log operation based on the selected type
        switch (logType) {
            case "log":
                if (num <= 0) throw new ArithmeticException("Logarithm of non-positive numbers is undefined.");
                result = Math.log10(num);
                break;
            case "ln":
                if (num <= 0) throw new ArithmeticException("Logarithm of non-positive numbers is undefined.");
                result = Math.log(num);
                break;
            default:
                JOptionPane.showMessageDialog(null, "Invalid log function.");
                return;
        }

        // Append the calculation and result to the history
        String calculation = logType + "(" + num + ") = " + result;
        history.append(calculation).append("\n");
        JOptionPane.showMessageDialog(null, "Result: " + result);  // Display the result
    }

    // Function to perform power operation (x^y)
    private static void performPowerOperation() {
        double base = getNumberInput("Enter the base (x):");  // Get base value from user
        if (base == Double.NaN) return;  // Exit if the user cancels or enters invalid input
        double exponent = getNumberInput("Enter the exponent (y):");  // Get exponent value from user
        if (exponent == Double.NaN) return;  // Exit if the user cancels or enters invalid input
        
        double result = Math.pow(base, exponent);  // Perform the power operation
        
        // Append the calculation and result to the history
        String calculation = base + "^" + exponent + " = " + result;
        history.append(calculation).append("\n");
        JOptionPane.showMessageDialog(null, "Result: " + result);  // Display the result
    }

    // Function to perform exponent operation (e^x)
    private static void performExponentOperation() {
        double exponent = getNumberInput("Enter the exponent (x):");  // Get exponent value for e^x
        if (exponent == Double.NaN) return;  // Exit if the user cancels or enters invalid input
        
        double result = Math.exp(exponent);  // Perform the exponent operation (e^x)
        
        // Append the calculation and result to the history
        String calculation = "e^" + exponent + " = " + result;
        history.append(calculation).append("\n");
        JOptionPane.showMessageDialog(null, "Result: " + result);  // Display the result
    }

    // Function to perform inverse operation (1/x)
    private static void performInverseOperation() {
        double num = getNumberInput("Enter the number:");  // Get number for inverse operation
        if (num == Double.NaN) return;  // Exit if the user cancels or enters invalid input
        
        if (num == 0) {
            JOptionPane.showMessageDialog(null, "Cannot divide by zero.");  // Handle division by zero
            return;
        }

        double result = 1 / num;  // Perform the inverse operation
        
        // Append the calculation and result to the history
        String calculation = "1/" + num + " = " + result;
        history.append(calculation).append("\n");
        JOptionPane.showMessageDialog(null, "Result: " + result);  // Display the result
    }

    // Function to perform negation operation (±)
    private static void performNegationOperation() {
        double num = getNumberInput("Enter the number:");  // Get number for negation
        if (num == Double.NaN) return;  // Exit if the user cancels or enters invalid input
        
        double result = -num;  // Negate the number
        
        // Append the calculation and result to the history
        String calculation = "Negate (" + num + ") = " + result;
        history.append(calculation).append("\n");
        JOptionPane.showMessageDialog(null, "Result: " + result);  // Display the result
    }

    // Function to save a value to memory
    private static void memorySave() {
        double num = getNumberInput("Enter the number to save to memory:");  // Get number to save to memory
        if (num == Double.NaN) return;  // Exit if the user cancels or enters invalid input
        
        memory = num;  // Save the number to memory
        JOptionPane.showMessageDialog(null, "Memory saved: " + memory);  // Display memory saved message
    }

    // Function to recall the saved value from memory
    private static void memoryRecall() {
        JOptionPane.showMessageDialog(null, "Memory recall: " + memory);  // Display the saved memory value
    }

    // Function to clear the saved value from memory
    private static void memoryClear() {
        memory = 0;  // Clear memory
        JOptionPane.showMessageDialog(null, "Memory cleared.");  // Display memory cleared message
    }

    // Function to view the history of calculations
    private static void viewHistory() {
        JOptionPane.showMessageDialog(null, history.toString());  // Display the calculation history
    }

    // Function to clear the history of calculations
    private static void clearHistory() {
        history.setLength(0);  // Clears the history
        JOptionPane.showMessageDialog(null, "History cleared.");  // Display history cleared message
    }

    // Utility method to prompt for number input with error handling
     private static double getNumberInput(String prompt) {
        while (true) {
            String input = JOptionPane.showInputDialog(null, prompt);
            if (input == null) {
                return Double.NaN; // Use NaN as a signal to go back
            }
            try {
                return Double.parseDouble(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.", 
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}

